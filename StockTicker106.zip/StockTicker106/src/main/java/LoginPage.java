
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author Hank
 */


public class LoginPage extends JFrame {  
    private static test frame = new test();
    private static LoginPage Tframe = new LoginPage();
    public static void main(String[] args) {
        
        Tframe.setTitle("Login & Register");
        Tframe.setSize(300, 300);
        Tframe.setResizable(false);
        Tframe.setLocationRelativeTo(null); // Center the frame   
        Tframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Tframe.setVisible(true);
    }
    public LoginPage(){
        JPanel createAccountP = new JPanel();
        JPanel mainPanel = new JPanel();
        
        
        //Main Panel
        add(mainPanel);
        mainPanel.setLayout(new GridLayout(4,0));

        JPanel mainPanelP1 = new JPanel();
        mainPanel.add(mainPanelP1);
        JPanel mainPanelP2 = new JPanel();
        mainPanel.add(mainPanelP2);
        JPanel mainPanelP3 = new JPanel();
        mainPanel.add(mainPanelP3);
        JPanel mainPanelP4 = new JPanel();
        mainPanel.add(mainPanelP4);
        
        JLabel welcome = new JLabel("Login");
        welcome.setFont(new Font("Serif", Font.PLAIN, 40));
        mainPanelP1.add(welcome);
        
        JLabel usernameLabel_main = new JLabel("Username:");
        JTextField usernameT_main =  new JTextField(20);
        String username_main = usernameT_main.getText();   
        mainPanelP2.add(usernameLabel_main);
        mainPanelP2.add(usernameT_main);
        
        JLabel passwordLabel_main = new JLabel("Password:");
        JPasswordField passwordT_main =  new JPasswordField(20);
        char[] password_main = passwordT_main.getPassword();
        mainPanelP3.add(passwordLabel_main);
        mainPanelP3.add(passwordT_main);
        //passwordT_main.addActionListener((ActionListener) this);
        
        
        JButton login = new JButton("Login");
        mainPanelP4.add(login);
        
        
        JButton register = new JButton("Register");
        mainPanelP4.add(register);
        //mainPanelP4.setLayout(new GridLayout(0,2));
        
        
        //register panel or create account panel
        createAccountP.setLayout(new GridLayout(4,0));
        //add(createAccountP);
        
        JPanel createAccountP1 = new JPanel();
        createAccountP.add(createAccountP1);
        JPanel createAccountP2 = new JPanel();
        createAccountP.add(createAccountP2);
        JPanel createAccountP3 = new JPanel();
        createAccountP.add(createAccountP3);
        JPanel createAccountP4 = new JPanel();
        createAccountP.add(createAccountP4);

        
               
        JLabel usernameLabel = new JLabel("Enter an Username:");
        JTextField usernameT =  new JTextField(20);
        String username = usernameT.getText();   
        createAccountP1.add(usernameLabel);
        createAccountP1.add(usernameT);
        
        
        
        JButton hint = new JButton("Hint");
        
        hint.addActionListener(new ActionListener() {   
            @Override
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(null,"\nYour password must contain at least: "
                       + "\n- one upper and one lower case alpha character, "
                       + "\n- one numeric number, "
                       + "\n- one special character.\n");
            }
        });
      
        
        JLabel passwordLabel = new JLabel("Enter a Password:");
        JPasswordField passwordT = new JPasswordField(20);
        char[] password = passwordT.getPassword();
        createAccountP2.add(passwordLabel);
        createAccountP2.add(hint);
        createAccountP2.add(passwordT);
        
        
        JLabel confirmLable = new JLabel("Re-enter the Password:");  
        JPasswordField confirmT =  new JPasswordField(20); 
        char[] confirm = confirmT.getPassword(); 
        createAccountP3.add(confirmLable);
        createAccountP3.add(confirmT);
        
        JButton back = new JButton("Back");
        createAccountP4.add(back);      
        JButton submit = new JButton("Submit");
        createAccountP4.add(submit);       
        //createAccountP4.setLayout(new GridLayout(0,2));
        
        submit.addActionListener(new ActionListener() {
            
            //boolean condition;
            //boolean condition = isValid(password);
            boolean boo = false;
            
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                String username = usernameT.getText();
                System.out.println(username);
                char[] password = passwordT.getPassword();
                char[] confirm = confirmT.getPassword();
                
                while (boo == false) {
                    //condition = isValid(password);
                    if (!isMatch(password, confirm))
                    {
                        JOptionPane.showMessageDialog(null, "The password doesn't match! "
                                + "Please enter the password again!");
                        System.out.println("Password: " + password + "; Password2: " + confirm);
                        break;
                      
                    }
                    else if(password.length == 0)
                    {
                        JOptionPane.showMessageDialog(null, "Please fill the password column!");
                        break;           
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "You have successfully registered the account!");
                        System.out.println("Password: " + password + "; Password2: " + confirm);
                        setContentPane(mainPanel);
                        invalidate();
                        validate();
                        BufferedWriter writer = null;
                        try {
                            //"true" means add to the file
                            writer = new BufferedWriter(new FileWriter("accountInfo.txt", true));
                            writer.write("***"); //indicator*
                            writer.newLine();
                            writer.write(username);
                            //System.out.println("Password: " + password + "; Password2: " + confirm);
                            writer.newLine();
                            writer.write(password);
                            writer.newLine();
                            writer.flush();
                        } catch (IOException e) {
                            System.err.println(e);
                        } finally {
                            if (writer != null) {
                                try {
                                    writer.close();
                                } catch (IOException e) {
                                    System.err.println(e);
                                }
                            }
                        }
                        break;
                        //Store the password and username here
                        //write to the file that start with '***', which tells program read the next 
                            //two lines as username and password, if these match to the user input, 
                            // grant access
                    }
                }   
            }
        });
        
        back.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent ae) {
                setContentPane(mainPanel);
                invalidate();
                validate();
            }
        });
        register.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent ae) {
                setContentPane(createAccountP);
                invalidate();
                validate();
            }
        });
        
        login.setMnemonic(KeyEvent.VK_ENTER);
        
        login.addActionListener(new ActionListener() {
            boolean passwordB = false;
            
            @Override
            public void actionPerformed(ActionEvent ae) {  
     
                try{
                        String username_main = usernameT_main.getText();
                        char[] password_main = passwordT_main.getPassword();
                        BufferedReader in = new BufferedReader(new FileReader("accountInfo.txt"));
                        String str;
                        
                        System.out.println("You hitted login button!");
                        //System.out.println(username_main);
                        //java.util.List<String> list = new ArrayList<String>();
                        while((str = in.readLine()) != null){
                            if(str.equals("***")){
                                //String l1 = in.readLine();
                                String un = in.readLine();
                                char[] pw = in.readLine().toCharArray();
                                //str = in.readLine();
                                System.out.println("un= "+ un +", pw= "+ pw + 
                                        ", username_main= " +username_main +", "
                                        + "password_main= " + password_main);
                                if(username_main.equals(un) && isMatch(password_main,pw)){
                                    passwordB = true;
                                }else{
                                    
                                    //JOptionPane.showMessageDialog(null, "Password Wrong!");
                                }
                            }

                        }
                        if (passwordB == true){
                            JOptionPane.showMessageDialog(null, "You"
                                        + " have successfully logged-in!");
                            
                            frame.setTitle("Menu");
                            frame.setLocation(350,200);
                            frame.setSize(800,500);
                            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            frame.setVisible(true);
                            //frame.setLayout(new BorderLayout());
                            frame.setFocusable(true);
                            
                            Tframe.setVisible(false);
                            
                            
                            
                        }else{
                             JOptionPane.showMessageDialog(null, "Invalid "
                                     + "password. Try again.",
                                "Error Message", JOptionPane.ERROR_MESSAGE);
                        }
                            
                    }
                catch(FileNotFoundException e){
                    System.out.print("file not found");
                }
                catch (IOException ex) {
                    System.out.println("io error");
                }
            }
            
        });
        passwordT_main.addActionListener(new ActionListener() {
            boolean passwordB = false;
            
            @Override
            public void actionPerformed(ActionEvent ae) {  
     
                try{
                        String username_main = usernameT_main.getText();
                        char[] password_main = passwordT_main.getPassword();
                        BufferedReader in = new BufferedReader(new FileReader("accountInfo.txt"));
                        String str;
                        
                        System.out.println("You hitted login button!");
                        //System.out.println(username_main);
                        //java.util.List<String> list = new ArrayList<String>();
                        while((str = in.readLine()) != null){
                            if(str.equals("***")){
                                //String l1 = in.readLine();
                                String un = in.readLine();
                                char[] pw = in.readLine().toCharArray();
                                //str = in.readLine();
                                System.out.println("un= "+ un +", pw= "+ pw + 
                                        ", username_main= " +username_main +", "
                                        + "password_main= " + password_main);
                                if(username_main.equals(un) && isMatch(password_main,pw)){
                                    passwordB = true;
                                }else{
                                    
                                    //JOptionPane.showMessageDialog(null, "Password Wrong!");
                                }
                            }

                        }
                        if (passwordB == true){
                            JOptionPane.showMessageDialog(null, "You"
                                        + " have successfully logged-in!");
                            
                            frame.setTitle("Menu");
                            frame.setLocation(350,200);
                            frame.setSize(800,500);
                            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            frame.setVisible(true);
                            //frame.setLayout(new BorderLayout());
                            frame.setFocusable(true);
                            
                            Tframe.setVisible(false);
                            
                            
                            
                        }else{
                             JOptionPane.showMessageDialog(null, "Invalid "
                                     + "password. Try again.",
                                "Error Message", JOptionPane.ERROR_MESSAGE);
                        }
                            
                    }
                catch(FileNotFoundException e){
                    System.out.print("file not found");
                }
                catch (IOException ex) {
                    System.out.println("io error");
                }
            }
            
        });
        
        
    }
    public static boolean isMatch(char[] password, char[] confirm) {
        boolean isMatch = false;
        //char[] correctPassword = { 'a', 'b', 'c'};
 
        if (password.length != confirm.length) {
            isMatch = false;
        }
        if (Arrays.equals (password, confirm)){
            isMatch = true;
        }
 
        //Zero out the password.
        //Arrays.fill(correctPassword,'0');
 
        return isMatch;
    }
    public static boolean isValid(char[] password) {
        Boolean atleastOneUpper = false;
        Boolean atleastOneLower = false;
        Boolean atleastOneDigit = false;
        Boolean atLeastOneSpecialCase = false;

        if (password.length < 8) {
            return false;
        }

        for (int i = 0; i < password.length; i++) {
            if (Character.isUpperCase(password[i])) {
                atleastOneUpper = true;
            }
            else if (Character.isLowerCase(password[i])) {
                atleastOneLower = true;
            }
            else if (Character.isDigit(password[i])) {
                atleastOneDigit = true;
            }
            else{
                atLeastOneSpecialCase = true;
            }
                
        }

        return (atleastOneUpper && atleastOneLower && 
                atleastOneDigit && atLeastOneSpecialCase);
    }
    
    

}

