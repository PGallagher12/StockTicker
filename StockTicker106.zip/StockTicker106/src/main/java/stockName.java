

/**
 *
 * @author Hank
 * 
 * ####################
 * #NOTE:
 * #    Problems:
 * #          1. Can't set size for JPanel or JLabel @line 116
 * #          2. Search function won't preceed too much result 
 *                  if I change to show the full name of the company, 
 *                  string out of index @line 98
 * #          3. Possibly, using Y-axis alignment, but need to show 
 *                   two JLabel at the same time horizontally, and rest
 *                   vertically
 * #
 * #
 * #
 */

//import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import org.patriques.AlphaVantageConnector;
import org.patriques.TimeSeries;
import org.patriques.input.timeseries.Interval;
import org.patriques.input.timeseries.OutputSize;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.timeseries.IntraDay;
import org.patriques.output.timeseries.data.StockData;



public class stockName extends JPanel{
    //private static stockName stockName = new stockName();
    private JTextField SearchBox = new JTextField(10);
    private JButton name1 = new JButton();
    private String acr = "";
    private JButton[] buttonGroup = new JButton[30000];
    private String buttonName;
    private JFrame jdHelpScreen = new JFrame();
    private helpframe hf = new helpframe();
    private JButton jbHelp = new JButton("?");
    
    
    public stockName(GetStock gs) {
        try{
        BufferedReader in = new BufferedReader(new FileReader("StockNames.txt"));
        
        
        String str;

        List<String> list = new ArrayList<String>();
        while((str = in.readLine()) != null){
            list.add(str);
        }
       

        String[] data = list.toArray(new String[0]);
        int Lsize = data.length;
        //System.out.println(data[1]);
        
        //Create a p1 panel #1
        JPanel p1 = new JPanel();
        
        JLabel searchLabel = new JLabel("Enter a new seach:");
        searchLabel.setForeground(Color.white);
        
        p1.add(searchLabel, BorderLayout.WEST);
        add(p1, BorderLayout.NORTH);
        p1.add(SearchBox, BorderLayout.NORTH);
        
        JButton search = new JButton("Search");
        p1.add(search, BorderLayout.SOUTH);
        p1.add(jbHelp,BorderLayout.SOUTH);
        search.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        
        p1.setBackground(Color.BLACK);
        
        
        //p2
        JPanel p2 = new JPanel();
        add(p2, BorderLayout.CENTER);

        p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));
        //p2.setLayout(new GridLayout(0,2));
        
       
        
        JScrollPane scrollBar = new JScrollPane(p2);
        scrollBar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollBar);
        jbHelp.addActionListener (new ActionListener() {
        	
        	@Override
        	public void actionPerformed(ActionEvent arg0) {
        		jdHelpScreen.add(hf);
        		jdHelpScreen.setTitle("Help");
        		jdHelpScreen.setSize(800, 500);
        		jdHelpScreen.setVisible(true);
        		
        	}
        });
        
        
        search.addActionListener((ActionEvent ae) -> {
        	
        	System.out.println("Hello");
            p2.removeAll(); //clear the panel before reprint
            String textFieldValue = SearchBox.getText();
            int ResultCounter = 0;
            List<String> varButtons = new ArrayList<String>();
            for (int i = 0; i < Lsize; i++) {
           
                boolean bool = data[i].contains(textFieldValue) ||
                        data[i].toUpperCase().contains(textFieldValue)||
                        data[i].toLowerCase().contains(textFieldValue);
                //System.out.println("data"+ "[" + i +"] is "+ data[i] + "."
                //+ "Found " + textFieldValue + "?: " + bool);
                if (bool == true) {
                    String s = "";
                    acr = "";
                    //JButton name1 = new JButton("");
                    //JButton fav = new JButton("鉁�");
                    int count = 0;
                    
                        for (int p = 0; p < data[i].length(); p++)
                        {
                            s += data[i].charAt(p);
                            if (data[i].charAt(p+1) == '|' && acr == "")
                            {
                                acr = s;
                            }
                            if (data[i].charAt(p+1) == '|')
                            {
                                count ++;
                            }
                            if (count == 2)
                            {     
                                name1= new JButton(s);
                                count = 0;
                                buttonGroup[i]=name1;
                                
                                varButtons.add(acr);
                                
                
                                name1.addActionListener(new ActionListener (){
                                String bName = "";
                                    @Override
                                    public void actionPerformed(ActionEvent e){
                                    	for (int j = 0;j<buttonGroup.length;j++) {
                                    		if(e.getSource()==buttonGroup[j]) {
                                    			buttonName = buttonGroup[j].getText();
                                    		}
                                    			
                                    	}
                                    	
                                    	for (int j = 0;j<buttonName.length();j++) {
                                        	if(buttonName.charAt(j)!='|') {
                                        		bName+= buttonName.charAt(j);
                                        	}
                                        	else {
                                        		break;
                                        	}
                                        }

                                    	
                                        StockDisplay.run(gs, bName);
                                        bName = "";
                                        
                                    }
                                    
                                });
                                p2.add(name1);
                                break;
                            }
                            
                            
                        }
                        
                    
                    //p2.add(fav);
                    //p2.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                } else {
                    ResultCounter ++;
                }
            }
            if (ResultCounter == Lsize)
            {
                p2.removeAll();
                JLabel NoResult = new JLabel("Scanned all "+ResultCounter+
                        " items in stock database, No Match Found!");
                NoResult.setFont(new Font("Serif", Font.BOLD, 16));
                p2.add(NoResult, BorderLayout.CENTER);
                p2.revalidate();
                p2.repaint();
            }
            //System.out.println(ResultCounter);
            p2.revalidate();
            p2.repaint();
        });
        
        
       
    
         }catch(FileNotFoundException e){
        System.out.print("file not found");
        } catch (IOException ex) {
           System.out.println("io error");
        }
    }

}

    /**
     * @param args the command line arguments
     */

    /**
     *
     * @param args the command line arguments
     * @throws java.io.IOException
     */

    /**
     *
     * @param args the command line arguments
     */
  
