import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.patriques.AlphaVantageConnector;
import org.patriques.TimeSeries;
import org.patriques.input.timeseries.Interval;
import org.patriques.input.timeseries.OutputSize;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.timeseries.Daily;
import org.patriques.output.timeseries.IntraDay;
import org.patriques.output.timeseries.Monthly;
import org.patriques.output.timeseries.data.StockData;


/**
 *
 * @author zhang
 */
public class GetStock {
    
    List<String> savedStockL = new ArrayList<String>();
    List<List<StockData>> preloadListHour = new ArrayList<List<StockData>>();
    List<List<StockData>> preloadListDay = new ArrayList<List<StockData>>();
    List<List<StockData>> preloadListMonth = new ArrayList<List<StockData>>();  
    String apiKey = "98JSUNDTZL2206OO";
    int timeout = 5000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
    TimeSeries stockTimeSeries = new TimeSeries(apiConnector);
    public  GetStock(){

    try (BufferedReader br = new BufferedReader(new FileReader("AddedStocks.txt")))
    {
        String sCurrentLine;
        int i =0;
        while ((sCurrentLine = br.readLine()) != null)
        {
        	if(sCurrentLine.contains("#")) {
        		String[] stock = sCurrentLine.split("#");
        		savedStockL.add(i, stock[1]) ;
 
        		System.out.println(savedStockL.get(i)+ " loaded");
        		i++;
        	}
        }
    }
    
    catch (IOException e)
    {
        e.printStackTrace();
    }
    
    //load hourly data
    for(int i =0; i<savedStockL.size();i++){
        boolean done = false;
        while(!done){
            System.out.println("Trying hourly");
            try{
             preloadListHour.add(stockTimeSeries.intraDay(savedStockL.get(i), Interval.SIXTY_MIN, OutputSize.COMPACT).getStockData());
            
             done = true;
            }
            catch (AlphaVantageException e) {
                System.out.println("w8");
            }
        }
    }
    
    //load daily data
    for(int i =0; i<savedStockL.size();i++){
        boolean done = false;
        while(!done){
            System.out.println("Trying daily");
            try{
            
             preloadListDay.add(stockTimeSeries.daily(savedStockL.get(i)).getStockData());
             done = true;
            }
            catch (AlphaVantageException e) {
                System.out.println("w8");
            }
        }
    }
    //load monthly data
  
    for(int i =0; i<savedStockL.size();i++){
        boolean done = false;
        while(!done){
            System.out.println("Trying monthly");
            if (i == 61)
            	break;
            try{
             preloadListMonth.add(stockTimeSeries.monthly(savedStockL.get(i)).getStockData());
             done = true;
            }
            catch (AlphaVantageException e) {
                System.out.println("w8");
            }
        }
    }
    

    
        
        
    }
    public List<StockData> getStockData (String symbol, String timePeriod){
        int index =-1;
        List<StockData> result = null ;
        for(int i = 0;i<savedStockL.size();i++){
            if(symbol.equals(savedStockL.get(i))){
                index = i;
                break;
            }
        }
        if (index == -1){
            System.out.println("Stock Data Not Loaded");
            
            if(timePeriod.equals("h")){
            	System.out.println("Loading hourly data...");
                result = getEveryHour(symbol).stream().collect(Collectors.toList());
            }
            else if(timePeriod.equals("d")){
            	System.out.println("Loading daily data...");
                result = getEveryDay(symbol).stream().collect(Collectors.toList());
            }   
            else if(timePeriod.equals("m")){
            	System.out.println("Loading monthly data...");
                result = getEveryMonth(symbol).stream().collect(Collectors.toList());
            }
        }
            
        
        else{
      
            if(timePeriod.equals("h")){
                result = preloadListHour.get(index).stream().collect(Collectors.toList());
            }
            else if(timePeriod.equals("d")){
                result = preloadListDay.get(index).stream().collect(Collectors.toList());
            }   
            else if(timePeriod.equals("m")){
                result = preloadListMonth.get(index).stream().collect(Collectors.toList());
            }
            
            
        }
        return result;
    }
    public  static List<StockData> getEveryHour(String arc){
                String apiKey = "98JSUNDTZL2206OO";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
     List<StockData> LEveryHour = null;
    
    TimeSeries stockTimeSeries = new TimeSeries(apiConnector);
    boolean done = false;
    while(!done){
    try {   
      System.out.println("done0");
      IntraDay response = stockTimeSeries.intraDay(arc, Interval.SIXTY_MIN, OutputSize.COMPACT);

      LEveryHour = response.getStockData();


   
      done =true;
    } catch (AlphaVantageException e) {
      System.out.println("something went wrong");
    }
    }
       
    return LEveryHour;
    }
    public  static List<StockData> getEveryDay(String arc){
    String apiKey = "98JSUNDTZL2206OO";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
     List<StockData> LEveryDay = null;
    
    TimeSeries stockTimeSeries = new TimeSeries(apiConnector);
    boolean done = false;
    while(!done){
    try {   
      System.out.println("done0");
      Daily response = stockTimeSeries.daily(arc);
     
  
      LEveryDay = response.getStockData();

     done =true;
    } catch (AlphaVantageException e) {
      System.out.println("something went wrong");
    }
    }
       
    return LEveryDay;
    }
public  static List<StockData> getEveryMonth(String arc){
    String apiKey = "98JSUNDTZL2206OO";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
     List<StockData> LEveryMonth = null;
    
    TimeSeries stockTimeSeries = new TimeSeries(apiConnector);
    boolean done = false;
    while(!done){
    try {   
      System.out.println("done0");
      Monthly response = stockTimeSeries.monthly(arc);

      LEveryMonth = response.getStockData();



   
      done =true;
    } catch (AlphaVantageException e) {
      System.out.println("something went wrong");
    }
    }
       
    return LEveryMonth;
    }

    

  
}