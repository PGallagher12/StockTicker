import java.awt.Color;
import java.awt.Graphics;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.patriques.output.timeseries.data.StockData;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zhang
 */



  /** Main method */
  

   public class StockGraph extends JPanel {
        List<StockData> Lday;
        String Sday;
        int length;
     
    public static void run(List<StockData> Lday, int timeLength) {
    String Sday =  Lday.get(Lday.size()-1).getDateTime().toString().substring(0,11);
    JFrame frame = new JFrame();  
    frame.setTitle("StockDailyGraph");
    frame.add(new StockGraph(Lday, timeLength));
    frame.setLocationRelativeTo(null); // Center the frame
    frame.setSize(600, 600);
    frame.setVisible(true);
  }
      
    
    StockGraph(List<StockData> Lday, int timeLength) {
        super();
        this.length = timeLength;
        String Sday =  Lday.get(Lday.size()-1).getDateTime().toString().substring(0,11);
        this.Lday = Lday.stream().collect(Collectors.toList());
        System.out.println("to paintcomponent");
        
    }
    
    public void repaintGraph(int timeLength){
        this.length = timeLength;
        this.repaint();
    }
  @Override
  protected void paintComponent(Graphics g) {
    
    int initVolume =(int) Lday.get(0).getVolume();
    int initPrice = (int) Lday.get(0).getHigh();
    int maxVolume = initVolume;
    int maxPrice = initPrice;
    int minPrice = initPrice;
    System.out.println("The length now is "+this.length);
     for (int i = 0; i<length;i++){
         if (Lday.get(i).getVolume()>maxVolume){
             maxVolume = (int) Lday.get(i).getVolume();
         }
         
         if (Lday.get(i).getHigh()>maxPrice){
             maxPrice = (int) Lday.get(i).getHigh();
         }
         else {
        	 minPrice = (int)Lday.get(i).getHigh();
         }
     }
     int midPrice = (maxPrice-minPrice)/2+minPrice;
    
    super.paintComponent(g);
    

    int xWidth  = getWidth();        // Panel Width
    //System.out.println(initVolume +" ini max "+maxVolume);
    //System.out.println("width is "+xWidth);
    int yHeight = getHeight();
    //System.out.println("height is "+yHeight);
    int xBorder = xWidth/10;                // The gap to leave on each side
    int yBorder = yHeight/10;
    int xOrigin = xBorder;           // The origin is at (10, height- 40)
    int yOrigin = yHeight - 2* yBorder;
    int xAxisLength = xWidth-xBorder;
    int yAxisLength = yOrigin-yBorder;
    int barSpace = 1;                // ... space between bars
    double gHeight =  yHeight/10*8; // the height of the graph
    double gWidth = xWidth/10*8;    // the width of the graph
 
    
    double priceCoeff = gHeight/midPrice;
    double volumeCoeff = gHeight/maxVolume;
    //System.out.println(volumeCoeff);
    int barWidth = (int) (gWidth/length);
    int onePart = (int) (gWidth/length);
    int j =0;

    
    
    g.drawLine(xOrigin, yOrigin, (int) (gWidth+xBorder), yOrigin);   // Draw X-axis
    g.drawLine(xOrigin, yOrigin, xOrigin, yBorder);
//volume unit
    g.drawString("Volume", xOrigin-xBorder/3-10, yBorder);
    g.drawString(String.valueOf(initVolume/100000+"M"), xOrigin-xBorder/3-10, (yOrigin-yBorder)/6*3+yBorder);
    g.drawString(String.valueOf(initVolume/3*2/100000+"M"), xOrigin-xBorder/3-10, (yOrigin-yBorder)/6*4+yBorder);
    g.drawString(String.valueOf(initVolume/3/100000+"M"), xOrigin-xBorder/3-10, (yOrigin-yBorder)/6*5+yBorder);
    g.drawString("0", xOrigin-xBorder/3-10, yOrigin);
    //price unit
    g.drawLine((int) gWidth+xBorder, yOrigin, (int) gWidth+xBorder, yBorder);
    g.drawString("Price", xWidth-xBorder, yBorder-20);

    g.drawString(String.valueOf(maxPrice-(maxPrice-minPrice)/6), xWidth-xBorder, (yOrigin-yBorder)/6+yBorder-30);
    g.drawString(String.valueOf(maxPrice-(maxPrice-minPrice)/6*2), xWidth-xBorder, (yOrigin-yBorder)/6*2+yBorder-30);
    g.drawString(String.valueOf(maxPrice-(maxPrice-minPrice)/6*3), xWidth-xBorder, (yOrigin-yBorder)/6*3+yBorder-30);
    g.drawString(String.valueOf(maxPrice-(maxPrice-minPrice)/6*4), xWidth-xBorder, (yOrigin-yBorder)/6*4+yBorder-30);
    g.drawString(String.valueOf(minPrice), xWidth-xBorder, (yOrigin-yBorder)/6*5+yBorder-30);
    // draw title
//    g.drawString("Stock Price and Volume from"+Sday.substring(0, 8) +" to today", xAxisLength/3, yBorder/2 );

    //paint the volume
    System.out.println("Max Price is "+ maxPrice);
    System.out.println("MIn Price is "+ minPrice);
    System.out.println("Mid Price is "+ midPrice);
    System.out.println("Price coeff is "+ priceCoeff);
    g.setColor(new Color(23,102,232)); 
    for(int i = length;i>0;i--){
 
            g.fillRect(xOrigin+onePart*(length-i),yOrigin-(int)(Lday.get(i-1).getVolume()*volumeCoeff), barWidth,(int)(Lday.get(i-1).getVolume()*volumeCoeff) );
            //System.out.println("the volume at date and time  "+Lday.get(i).getDateTime());
        
  
    }
    //paint the high price
    g.setColor(new Color(77,240,15));
    System.out.println("gHeight is "+gHeight);
    for(int i = length-1;i>0;i--){
        
        g.drawLine(xOrigin+onePart*(length -i), (int) (gHeight/2-((Lday.get(i).getHigh())-midPrice)*priceCoeff),
                xOrigin+onePart*(length-i+1), (int) (gHeight/2-((Lday.get(i-1).getHigh())-midPrice)*priceCoeff));
    }
    //paint the low price
      g.setColor(new Color(237,221,18));
    for(int i = length-1;i>0;i--){
      
    	 g.drawLine(xOrigin+onePart*(length -i), (int) (gHeight/2-((Lday.get(i).getLow())-midPrice)*priceCoeff),
                 xOrigin+onePart*(length-i+1), (int) (gHeight/2-((Lday.get(i-1).getLow())-midPrice)*priceCoeff));
    }
    
  }

   }
   