

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;




public class helpframe extends JPanel{
    public helpframe(){
			
    	
    	Font  header  = new Font(Font.SANS_SERIF , Font.BOLD, 30);
    	Font  words  = new Font(Font.SERIF , Font.PLAIN, 14);
    	
    	JPanel holder = new JPanel();
    	GridLayout Layout = new GridLayout(0,1);
    	holder.setLayout(Layout);
    	
    	
		JLabel title = new JLabel("NIRD STOCK TICKER HELP");
		title.setSize(200, 200);
		title.setFont( header );
		
		JTextArea intro = new JTextArea("Thank you for choosing the NIRD stock ticker program. We want the best for our clients, so here's what you need to know");
		intro.setSize(400, 100);
		JTextArea para1 = new JTextArea("After logging in, you should see your homepanel.  The top left should diplay your current investments.  Below that is a list of stocks you currently follow.  The right is an option to search for stocks ");
		para1.setSize(400, 100);
		JTextArea para2 = new JTextArea("After searching a stock, you will be brought to the stock information panel.  There you will see stock prices, names, and a graph of recent changes.  The graph may be adjusted by the buttons at the bottom of the panel.  From the same list of buttons, you may choose to add this to the list of stocks you'd like to follow.");
		para2.setSize(400, 100);
		
		intro.setFont( words );
		para1.setFont( words );
		para2.setFont( words );
	
		intro.setLineWrap(true);
		intro.setWrapStyleWord(true);
		intro.setEditable(false);
		intro.setOpaque(false);
		intro.setBorder(null);
		
		para1.setLineWrap(true);
		para1.setWrapStyleWord(true);
		para1.setEditable(false);
		para1.setOpaque(false);
		para1.setBorder(null);
		
		para2.setLineWrap(true);
		para2.setWrapStyleWord(true);
		para2.setEditable(false);
		para2.setOpaque(false);
		para2.setBorder(null);

		holder.add(title);
		holder.add(intro);
		holder.add(para1);
		holder.add(para2);
		add(holder);
		
		setVisible(true);		
		
	}
}
