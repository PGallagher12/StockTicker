import java.awt.*;
import javax.swing.*;
import org.patriques.output.timeseries.data.StockData;
import java.awt.event.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class test extends JFrame{
	private static test frame = new test();

	private JPanel jpName = new JPanel();
	private JPanel jpList = new JPanel();
	private JPanel jpSearch = new JPanel();
	private JButton jbStock = new JButton();
	GetStock gs = new GetStock();
	double totalPrice = 0;
	int total = 0;
	DecimalFormat dc = new DecimalFormat("0.00");
	
	public static void main(String[] args) {
		frame.setTitle("Menu");
		frame.setLocationRelativeTo(null);
		frame.setSize(1000,500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	
	public test() {
		JPanel jpMenu = new JPanel();
		jpMenu.setLayout(new GridLayout(1,2));
		jpMenu.add(jpName);
		jpName.setLayout(new GridLayout(2,2));
		JPanel info = new JPanel();
		info.setBorder(BorderFactory.createLineBorder(Color.black));
		info.setLayout(new GridLayout(2,2));
		
		jpList.setLayout(new GridLayout(1,3));
		JPanel add = new JPanel();
		jpList.add(add);
		//Panel that has the user information
		
		JScrollPane jsScroll = new JScrollPane(add);
		jsScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add.setLayout(new BoxLayout(add, BoxLayout.Y_AXIS));
		jpList.add(jsScroll);
		
		//Functions of Add Panel
		double Price = 0.00;
		double s = 0.00;
		try {
			BufferedReader in = new BufferedReader(new FileReader("AddedStocks.txt"));
			String str;
			java.util.List<String> list = new ArrayList<String>();
			while((str = in.readLine()) != null) {
				list.add(str);
			}
			String[] b = list.toArray(new String[0]);
		
			
			
			int isChecked[] = new int[b.length];
			
			for(int i = 0; i <b.length; i++) {
				System.out.println(b[i]);
				if(b[i].contains("*")) {
				}
				else if(b[i].contains("$")){
					Price = Double.valueOf(b[i].substring(1));
					totalPrice = totalPrice + Price;
					System.out.println(Price);
				}
				else if(b[i].contains("#")){
					String[] splitStock = b[i].split("#");
					//final int S = i;
					int count = 0;
					gs.getStockData(splitStock[1], "d");
				
					for(int k = 0; k<b.length; k++){
						if(b[i].equals(b[k])){
							count++;
							if(i!=k)isChecked[k] = 1;
						}
					}
					
					//Tells if the closed price is higher or lower than the price when bought
					double closedPrice = (double)gs.getStockData(splitStock[1], "d").get(0).getClose();
					if(Price >= closedPrice) {
						s = (Price-closedPrice)*-1;
					}
					else if(Price < closedPrice) {
						s = closedPrice-Price;
					}
					
					String te = dc.format((s/(double)gs.getStockData(splitStock[1], "d").get(0).getClose())*100);
					double percent = Double.valueOf(te);
					
					
					
					if(isChecked[i] == 0) {
						if(percent > 0) {
							try {
								Image img = new ImageIcon("Green Arrow.svg").getImage().getScaledInstance(20,20,1);
								ImageIcon green = new ImageIcon(img);
								jbStock = new JButton("<html>" +splitStock[1] + " - " + count+ "<br />" + "%"+percent + "</html>", green);
								add.add(jbStock);
								
							}catch (Exception ex){
								System.out.println("EX");
							}
						}
						else {
							try {
								Image img = new ImageIcon("Red Arrow.svg").getImage().getScaledInstance(20,20,1);
								ImageIcon red = new ImageIcon(img);
								jbStock = new JButton("<html>" +splitStock[1] + " - " + count+ "<br />" + "%"+percent + "</html>", red);
								add.add(jbStock);
								
							}catch (Exception ex){
								System.out.println("EX");
							}
							
						}
					
						jbStock.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent arg0) {
							StockDisplay.run(gs,splitStock[1]);

						}
					
					});
						
					}
				
					total++;
					
				}
				
				
			}
		} catch(FileNotFoundException e) {
			System.out.println("file not found");
		}catch(IOException ex) {
			System.out.println("io error");
		}
		
		
		
		//A big panel for Top Left of the main menu
		JPanel bigPanel = new JPanel();
        jpName.add(bigPanel);
        JPanel topPanel = new JPanel();
        JPanel s1Panel = new JPanel();
        JPanel s2Panel = new JPanel();
        JPanel s3Panel = new JPanel();
        //JPanel s4Panel = new JPanel();
        topPanel.setLayout(new GridLayout(0,2));
        bigPanel.setLayout(new GridLayout(2,0));
        topPanel.add(s1Panel);
        topPanel.add(s2Panel);
        bigPanel.add(topPanel);
        bigPanel.add(s3Panel);
        //bigPanel.add(s4Panel);
                
                
                
		//Adding the total prices of all added stocks
		JLabel jlTotalPrice = new JLabel("Total Price: " + dc.format(totalPrice));
		JLabel jlTotalStocks = new JLabel("Total Stocks: " + total);
        jlTotalPrice.setFont(new Font("Serif", Font.PLAIN, 20));
        jlTotalStocks.setFont(new Font("Serif", Font.PLAIN, 20));
        
        s1Panel.setLayout(new GridBagLayout());
        s2Panel.setLayout(new GridBagLayout());
		s1Panel.add(jlTotalStocks);
		s2Panel.add(jlTotalPrice);
		
		JPanel bought = new JPanel();
		bought.setLayout(new GridLayout(1,2));
		JLabel jlTotal = new JLabel("Total Stocks");
        jlTotal.setFont(new Font("Serif", Font.PLAIN, 20));
        s3Panel.setLayout(new GridBagLayout());
		s3Panel.add(jlTotal);
		JPanel f = new JPanel();
		f.setLayout(new GridLayout(1,2));
		
		//Wanted to add the favorite stocks, will do when we have time
		
		//bought.add(f);
		//JLabel m = new JLabel("Favorite Stocks");
                //m.setFont(new Font("Serif", Font.PLAIN, 25));
		//s4Panel.add(m);
		jpName.add(jpList);
		
		//The Search Panel
		jpSearch = new stockName(gs);
		jpSearch.setLayout(new GridLayout(2,1));
		jpMenu.add(jpSearch, BorderLayout.CENTER);
		
		add(jpMenu, BorderLayout.CENTER);

		
	}
}