
/* NAME: Spencer Russell
 * DATE: 3/22/17
 */

import javax.swing.*;

import org.patriques.output.timeseries.data.StockData;

import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
//import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
 
public class StockDisplay extends JFrame{
    
	
    public static void run(GetStock gs, String acr){
    	JButton jbAdd = new JButton("Add");
        JButton jbDaily = new JButton("7 Days");
        JButton jbWeekly = new JButton("14 Days");
        JButton jbMonthly = new JButton("3 Months");
        JButton jbYearly = new JButton("3 Year");

        JTextField jtfMulti = new JTextField(5);
        JButton jbDecrease = new JButton("↓");
        JButton jbIncrease = new JButton("↑");
        JButton jbRemove = new JButton("Remove");

        
        JPanel jpOutside = new JPanel();
        JPanel Panel = new JPanel();
        
    	StockDisplay frame  =  new StockDisplay();
        jpOutside.removeAll();
    	jpOutside.revalidate();
        frame.setTitle(acr);
        frame.setLocation(200,100);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        frame.setVisible(true);
        frame.setLayout(new BorderLayout());
        List<StockData> sL = gs.getStockData(acr, "h");
        int count = 1;
        String total = String.valueOf(count);
        StockGraph jpGraph = new StockGraph(sL,49);
        jpOutside.setLayout(new GridLayout(1,1));
        
        frame.add(jpOutside);
        jpOutside.add(jpGraph);
        double PriceWhenBought = Double.valueOf(sL.get(0).getClose());
        
        JPanel jpButtons = new JPanel();
        JPanel jpAmount = new JPanel();
        jpAmount.setLayout(new GridLayout(1,18));
        Panel.setLayout(new GridLayout(2,1));
        frame.add(Panel, BorderLayout.SOUTH);
        Panel.add(jpAmount);
        Panel.add(jpButtons);
        jtfMulti.setEditable(false);
        jtfMulti.setText(total);
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(jbDecrease, BorderLayout.SOUTH);
        jpAmount.add(jtfMulti, BorderLayout.SOUTH);
        jpAmount.add(jbIncrease, BorderLayout.SOUTH);
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        jpAmount.add(new JPanel());
        
        
        jpButtons.add(jbDaily, BorderLayout.SOUTH);
        //jpButtons.add(jbWeekly, BorderLayout.SOUTH);
        jpButtons.add(jbMonthly, BorderLayout.SOUTH);
        jpButtons.add(jbYearly, BorderLayout.SOUTH);
        jpButtons.add(jbAdd, BorderLayout.SOUTH);
        jpButtons.add(jbRemove, BorderLayout.SOUTH);
        
        jbAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				int count = Integer.valueOf(jtfMulti.getText());
				try {
					for(int i = 0; i < count; i++) {
						FileWriter writer = new FileWriter("AddedStocks.txt", true);
						writer.write("$"+String.valueOf(PriceWhenBought));
						writer.write("\r\n");
						writer.write("#"+acr);
						writer.write("\r\n*****\r\n");
						writer.close();
					}
				}catch(IOException ex) {
					ex.printStackTrace();
				}
			}
        	
        });
        
        jbDecrease.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int count = Integer.valueOf(jtfMulti.getText());
				if(count > 1) {
					count--;
					jtfMulti.setText(String.valueOf(count));
				}
				
			}
        	
        });
        
        jbIncrease.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int count = Integer.valueOf(jtfMulti.getText());
				count++;
				jtfMulti.setText(String.valueOf(count));
				
			}
        	
        });
        
        jbRemove.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				String lineToRemove = "#"+acr;
				String currentLine;
				//System.out.println(lineToRemove);
				try {
					BufferedReader reader = new BufferedReader(new FileReader("AddedStocks.txt"));
					FileWriter writer = new FileWriter("AddedStocks.txt", true);
					while ((currentLine = reader.readLine()) != null) {
						
						String trimmedLine = currentLine.trim();
						if(trimmedLine.equals(lineToRemove)) {
							System.out.println(lineToRemove);
							writer.write("");
						}
						
					}
					writer.close();
					reader.close();
				}catch(IOException ex) {
					ex.printStackTrace();
				}
			}
        	
        });
        
        jbDaily.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jpOutside.removeAll();
				jpOutside.revalidate();
				List<StockData> sL = gs.getStockData(acr, "h");
				StockGraph jpDailyGraph = new StockGraph(sL,49);
				jpOutside.add(jpDailyGraph);
				
			}
        	
        });
        
        jbWeekly.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				jpOutside.removeAll();
				jpOutside.revalidate();
				List<StockData> sL = gs.getStockData(acr, "h");
				StockGraph jpWeeklyGraph = new StockGraph(sL,90);
				jpOutside.add(jpWeeklyGraph);
			}
        	
        });
        
        jbMonthly.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jpOutside.removeAll();
				jpOutside.revalidate();
				List<StockData> sL = gs.getStockData(acr, "d");
				StockGraph jpMonthlyGraph = new StockGraph(sL,90);
				jpOutside.add(jpMonthlyGraph);
				
				
			}
        	
        });
        jbYearly.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jpOutside.removeAll();
				jpOutside.revalidate();
				List<StockData> sL = gs.getStockData(acr, "m");
				StockGraph jpYearlyGraph = new StockGraph(sL,36);
				jpOutside.add(jpYearlyGraph);
				//frame.add(jpGraph, BorderLayout.CENTER);
				
				
			}
        	
        });
    }
    public StockDisplay (){
        
        
    }

}

